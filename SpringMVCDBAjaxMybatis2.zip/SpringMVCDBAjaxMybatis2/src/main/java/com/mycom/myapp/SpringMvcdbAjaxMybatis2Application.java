package com.mycom.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcdbAjaxMybatis2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcdbAjaxMybatis2Application.class, args);
	}

}
